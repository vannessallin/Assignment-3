## Experience 2: Golf Camp Instructor at Junior Golf Academy


1. **What was it that you did?**
  - I worked as a golf camp instructor at Junior Golf Academy during the summer of 2016 and 2017. I taught young golf enthusiasts various aspects of the game, including swing techniques and course etiquette.


2. **When did you do it?**
  - I worked as a golf camp instructor during the summer of 2016 and 2017.


3. **What was good about it?**
  - It was incredibly rewarding to see young golfers develop their skills and passion for the game. The camaraderie among the camp staff and the joy on the kids' faces were highlights.


4. **What was your favorite memory of it?**
  - My favorite memory was when one of my students hit their first hole-in-one during a mini-golf tournament we organized.


5. **What didn't you enjoy about it?**
  - Balancing the different skill levels of the kids and managing the logistics of the camp could be challenging at times.


6. **Experience Grade: A** (couldn't be better)