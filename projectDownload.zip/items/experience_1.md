## Experience 1: Pro Shop Check-In at Heron Point Golf Course

1. **What was it that you did?**
   - I worked as a pro shop check-in attendant at Heron Point Golf Course from May 2015 to August 2017. My responsibilities included checking in golfers, managing tee times, and providing excellent customer service.

2. **When did you do it?**
   - I worked at Heron Point Golf Course from May 2015 to August 2017.

3. **What was good about it?**
   - It was an excellent opportunity to combine my passion for golf with a part-time job. Interacting with golf enthusiasts and being surrounded by the beautiful course made it enjoyable.

4. **What was your favorite memory of it?**
   - My favorite memory was organizing a successful charity golf event where the community came together for a great cause.

5. **What didn't you enjoy about it?**
   - Dealing with difficult customers during busy days could be challenging, but it was part of the job.

6. **Experience Grade: B** (for the most part enjoyable)