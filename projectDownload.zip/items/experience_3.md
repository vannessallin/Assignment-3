## Experience 3: Content Creator

1. **What was it that you did?**
   - I worked as a content creator from January 2018 to December 2019. My role involved creating engaging and informative videos for various clients.

2. **When did you do it?**
   - I worked from January 2018 to December 2019.

3. **What was good about it?**
   - It allowed me to unleash my creativity and storytelling skills. I enjoyed the variety of projects and the opportunity to collaborate with different teams.

4. **What was your favorite memory of it?**
   - My favorite memory was producing a video series that received positive feedback and significantly increased the company's online presence.

5. **What didn't you enjoy about it?**
   - Tight deadlines and occasional last-minute changes in project scope could be stressful.

6. **Experience Grade: A** (couldn't be better)