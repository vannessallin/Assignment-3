## Experience 4: Real Estate Videographer

1. **What was it that you did?**
   - I worked as a real estate videographer from January 2020 to December 2021. My role involved creating visually stunning videos to showcase properties and attract potential buyers.

2. **When did you do it?**
   - I worked from January 2020 to December 2021.

3. **What was good about it?**
   - I enjoyed capturing the beauty of homes through videography and contributing to successful property sales. It also improved my skills in real estate marketing.

4. **What was your favorite memory of it?**
   - My favorite memory was producing a video tour for a luxurious property that received widespread attention and led to a quick sale.

5. **What didn't you enjoy about it?**
   - Unpredictable weather conditions during outdoor shoots posed occasional challenges.

6. **Experience Grade: B** (for the most part enjoyable)